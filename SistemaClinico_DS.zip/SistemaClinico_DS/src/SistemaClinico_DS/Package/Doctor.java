/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaClinico_DS.Package;

/**
 *
 * @author User
 */
public class Doctor extends Persona {

	protected int regDoctor;
	protected String especialidad;
	public Cita cita;
	public Secretaria secretaria;

	public void recetar() {
		// TODO - implement Doctor.recetar
		throw new UnsupportedOperationException();
	}

	public void agregarPlanNut() {
		// TODO - implement Doctor.agregarPlanNut
		throw new UnsupportedOperationException();
	}

	public void ImprimirReceta() {
		// TODO - implement Doctor.ImprimirReceta
		throw new UnsupportedOperationException();
	}

	public void registraSecretaria() {
		// TODO - implement Doctor.registraSecretaria
		throw new UnsupportedOperationException();
	}

}
