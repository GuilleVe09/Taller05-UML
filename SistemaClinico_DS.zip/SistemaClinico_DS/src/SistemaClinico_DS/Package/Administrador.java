/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaClinico_DS.Package;

/**
 *
 * @author User
 */
public class Administrador extends Persona {

	public void registrarUsuario() {
		// TODO - implement Administrador.registrarUsuario
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Persona
	 */
	public void asignarRol(int Persona) {
		// TODO - implement Administrador.asignarRol
		throw new UnsupportedOperationException();
	}

}
