/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaClinico_DS.Package;

import java.sql.Date;

/**
 *
 * @author User
 */
public class Persona {

	protected String usuario;
	protected String clave;
	protected String nombre;
	protected String apellido;
	protected String cedula;
	protected String direccion;
	protected Date fechaNac;

	public void logIn() {
		// TODO - implement Persona.logIn
		throw new UnsupportedOperationException();
	}

	public void logOut() {
		// TODO - implement Persona.logOut
		throw new UnsupportedOperationException();
	}

}
