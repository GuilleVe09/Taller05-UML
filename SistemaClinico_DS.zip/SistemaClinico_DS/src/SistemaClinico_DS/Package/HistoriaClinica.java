/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaClinico_DS.Package;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class HistoriaClinica {

	protected int nro;
	protected ArrayList<String> enfermedades;
	protected ArrayList<String> alergias;
	protected ArrayList<String> otros;

}
