/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaClinico_DS.Package;

/**
 *
 * @author User
 */
public class Paciente extends Persona {

	protected String email;
	public Cita cita;
	public Receta receta;
	public HistoriaClinica hisotriaClinica;

	public boolean solicitarCita() {
		// TODO - implement Paciente.solicitarCita
		throw new UnsupportedOperationException();
	}

}
